<h3 class="tab-title"><?php echo esc_html($title); ?></h3>
<?php
echo ($map);